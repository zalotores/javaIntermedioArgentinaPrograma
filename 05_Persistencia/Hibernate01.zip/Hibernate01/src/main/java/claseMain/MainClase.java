package claseMain;

import modelos.Cancion;
import modelos.CancionSinAnotaciones;
import org.hibernate.Session;
import util.HibernateUtil;

public class MainClase {
    public static void main(String[] args) {
        System.out.println("Prueba de Hibernate");

        Cancion cancion = new Cancion();
        cancion.setNombre("Prueba1");
        cancion.setDuracion("1:42");
        cancion.setDisco("1");
        cancion.setGenero("1");
        cancion.setInterprete("1");

        try {

            //para clase sin anotaciones, cambia el sessionFactory
            //Get Session
            Session session = HibernateUtil.getSessionFactory().openSession();
            //start transaction
            session.beginTransaction();
            //Save the Model object
            session.persist(cancion);
            //Commit transaction
            session.getTransaction().commit();
            System.out.println("Cancion ID="+cancion.getId());

        }
        catch (Exception ex) {
            System.out.println("Error!");
            //System.out.println(ex.getMessage());
            System.out.println(ex.toString());
        }
        finally {
            //terminate session factory, otherwise program won't end
            HibernateUtil.getSessionFactory().close();
        }
    }
}
